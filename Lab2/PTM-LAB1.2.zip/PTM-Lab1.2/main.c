#include <avr/io.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <util/delay.h>
#include <avr/sfr_defs.h>
#include <math.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>

#include "HD44780.h"

#ifndef _BV
#define _BV(bit)				(1<<(bit))
#endif
#ifndef sbi
#define sbi(reg,bit)		reg |= (_BV(bit))
#endif

#ifndef cbi
#define cbi(reg,bit)		reg &= ~(_BV(bit))
#endif

int main() {
	LCD_Initalize();
	LCD_Home();
	char text[20];
	uint16_t i = 0;

	sbi(PORTD, PD6); //Ustawia pull Up
	sbi(PORTC, PC0);

	while (1) {
		LCD_Clear();
		LCD_GoTo(0, 0);
		sprintf(text, "Linia 1 :%d", i++);
		LCD_WriteText(text);

		if (bit_is_set(PIND, PD0)) {
			LCD_GoTo(0, 1);
			LCD_WriteText("Wcisnieto: 1");
		}

		if (bit_is_clear(PINC, PC0)) {
			LCD_GoTo(0, 1);
			LCD_WriteText("Wcisnieto: =");
		}

		_delay_ms(250);
	}
}
